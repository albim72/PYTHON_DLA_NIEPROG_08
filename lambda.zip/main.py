print((lambda a:a*2)(34))

x = lambda x:x+12
print(x(5))

y = lambda a,b,c=2:(a+b)*c
print(y(4,6.7,1.2))
print(y(12,5.5))


def policz(a,b,c):
    return (a+b)*c

print(policz(2,5,7))

def multi(n):
    return lambda a:a*n

print(multi(9)(45))

#przykład użycia funkcji wyższego rzędu

#funkcja wyższego rzędu
def funkcja(f,liczba):
    return f(liczba)

def dodaj_jeden(x):
    return x+1

def kwadrat(bok):
    return bok**2

#wywołanie funkcji wyższego rzędu
print(funkcja(dodaj_jeden,56))
print(funkcja(kwadrat,4.5))

print(funkcja(lambda x:x/8, 16))
print(funkcja(lambda x:x**3, 16))

liczby = [34,56,78,2,13,4,8,1,15,23,27,39,48,88,77,19,5]
#stwórz listę parzyste -> wstaw do tej listy wartości parzyste z tablicy liczby, do wykonania zadania użyj funkcję
#wyższego rzędu map oraz funkcję lambda

parzyste = list(map(lambda x:x%2==0,liczby))
print(parzyste)
#zmodyfukuj rozwiązanie za pomocą funkcji filter

parzyste = list(filter(lambda x:x%2==0,liczby))
print(parzyste)

#zbuduj tablicę qube i zamapuj do niej wartości z tablicy liczby w taki sposób że każda nowa wartość jest sześcianem
#wartości pierwotnej

qube = list(map(lambda x:x**3,liczby))
print(qube)





