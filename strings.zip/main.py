str_ = "Mecz miesiąca:\nKlub sportowy: \"Orły Wisła\" - \tTrener: Jan Kot\nlokalizacja: Janowiec\n" \
       "vs\nKlub sportowy: \"Biedronka Niwa\" - \tTrener: Adam Knot\nlokalizacja: Niwa\n"

print(str_)

#zapisz zawartość zmiennej str_ do dwóch plików: rtf oraz txt

f = open("mecz.rtf","w",encoding="utf-8")
f.write(str_)
f.close()

f = open("mecz.txt","w",encoding="utf-8")
f.write(str_)
f.close()

dtekst = "       niezwykle Ważna i Tajna wiadomość; TRE454355456;       i Tajna PrzEsYłKA"
print(dtekst.lower())
print(dtekst.upper())
print(dtekst.strip())
print(dtekst.replace("Tajna","Utajniona"))
podzial = dtekst.split(";")
print(podzial)
print(type(podzial))

for i,wart in enumerate(podzial):
       podzial[i] = podzial[i].strip()

print(podzial)
print(dtekst.find("Tajna"))
print(dtekst.endswith("ka"))
print(dtekst.endswith("KA"))

d = "pionierzy"
e = "1001"


print(d.isalpha())
print(e.isdigit())


