class Osoba:

    def __init__(self,imie,nazwisko,wiek,waga,wzrost):
        self.imie = imie
        self.nazwisko = nazwisko
        self.wiek = wiek
        self.waga = waga
        self.wzrost = wzrost
        self.kolor_oczu = "brązowe"
        self._info()

    def _info(self):
        print("tworzenie nowego obiektu -> Osoba....")

    def print_osoba(self):
        print(f"osoba -> imię: {self.imie}, nazwisko: {self.nazwisko}, wiek: {self.wiek} lat, "
              f"waga: {self.waga} kg, wzrost: {self.wzrost} cm")

    def wiekza10lat(self):
        return self.wiek + 10

    def czypracownik(self):
        return False

    def bmi(self):
        return self.waga/(self.wzrost/100)**2

    def opis_bmi(self):
        if self.bmi() < 18.5:
            return "niedowaga"
        elif self.bmi() <= 25:
            return "waga prawidłowa"
        elif self.bmi() <= 30:
            return "nadwaga"
        else:
            return "otyłość"

#stwórz funkcję wyliczająca współczynnik ppm -> zapotrzebowanie energetyczne (kcal) jako metodę klasy Osoba
#kobieta: ppm -> 655.1 + 9.563*self.waga + 1.85*self.wzrost - 4.676*self.wiek
#mężczyzna: ppm ->  66.5 + 13.75 * self.waga + 5.003 * self.wzrost - 6.775 * self.wiek

    def policzppm(self,plec):
        if plec.lower() == "k":
            return 655.1 + 9.563*self.waga + 1.85*self.wzrost - 4.676*self.wiek
        elif plec.lower() == "m":
            return 66.5 + 13.75 * self.waga + 5.003 * self.wzrost - 6.775 * self.wiek
        else:
            return "błędne oznaczenie płci...."

p1 = Osoba("Jan","Kot",39,89,174)
p1.print_osoba()
print(f"kolor oczu: {p1.kolor_oczu}")
print(f"wiek za 10 lat: {p1.wiekza10lat()}")
print(f"czy osoba jest pracownikiem? {p1.czypracownik()}")
print(f"bmi ciała wynosi: {p1.bmi():.2f}, opis: {p1.opis_bmi()}")
print(f"zapotrzebowanie energetyczne: {p1.policzppm('m'):.2f} kcal")

print("***************************************************")
p2 = Osoba("Aneta","Nowak",28,56,167)
p2.print_osoba()
p2.kolor_oczu = "niebieskie"
print(f"kolor oczu: {p2.kolor_oczu}")
print(f"wiek za 10 lat: {p2.wiekza10lat()}")
print(f"czy osoba jest pracownikiem? {p2.czypracownik()}")

print("***************************************************")
p3 = Osoba("Olga","Knot",45,61,172)
p3.print_osoba()
print(f"kolor oczu: {p3.kolor_oczu}")
print(f"wiek za 10 lat: {p3.wiekza10lat()}")
print(f"czy osoba jest pracownikiem? {p3.czypracownik()}")

class Pracownik(Osoba):

    #konstruktor z dziedziczeniem
    def __init__(self,imie,nazwisko,wiek,waga,wzrost,firma,stanowisko,latapracy,wynagrodzenie):
        super().__init__(imie,nazwisko,wiek,waga,wzrost)
        self.firma = firma
        self.stanowisko = stanowisko
        self.latapracy = latapracy
        self.wynagrodenie = wynagrodzenie

    def print_pracownik(self):
        print(f"dane pracownika -> firma: {self.firma}, stanowisko pracy: {self.stanowisko},"
              f" lata pracy: {self.latapracy}, wynagrodzenie: {self.wynagrodenie} zł")

    def czypracownik(self):
        return True


print("***************************************************")
e1 = Pracownik("Paweł","Kot",43,102,173,"ABC","dyrektor",12,10900)
e1.print_osoba()
e1.print_pracownik()
print(f"kolor oczu: {e1.kolor_oczu}")
print(f"wiek za 10 lat: {e1.wiekza10lat()}")
print(f"czy osoba jest pracownikiem? {e1.czypracownik()}")
print(f"bmi ciała wynosi: {e1.bmi():.2f}, opis: {e1.opis_bmi()}")
print(f"zapotrzebowanie energetyczne: {e1.policzppm('m'):.2f} kcal")

class Sport:

    def __init__(self,dycyplina,lata_upr,best_wynik):
        self.dycyplina = dycyplina
        self.lata_upr = lata_upr
        self.best_wynik = best_wynik

    def infosport(self):
        print(f"dyscyplina: {self.dycyplina}, lata uprawiania: {self.lata_upr}, "
              f"życiówka: {self.best_wynik}.")

class Ekstra:
    pass

class Student(Pracownik,Sport,Ekstra):

    #konstruktor z wielodziedziczeniem
    def __init__(self,imie,nazwisko,wiek,waga,wzrost,id_studenta,kierunek,rok_studiow,
                 firma="",stanowisko="",latapracy="",wynagrodzenie="",dycyplina="",lata_upr="",best_wynik=""):
        Pracownik.__init__(self,imie,nazwisko,wiek,waga,wzrost,firma,stanowisko,latapracy,wynagrodzenie)
        Sport.__init__(self,dycyplina,lata_upr,best_wynik)
        self.id_studenta = id_studenta
        self.kierunek = kierunek
        self.rok_studiow = rok_studiow

    def print_student(self):
        print(f"informacje o studencie -> nr: {self.id_studenta}, kierunek studiów: {self.kierunek}, "
              f"rok studiów: {self.rok_studiow}")

    def czypracownik(self):
        return self.firma != ""


print("***************************************************")
s1 = Student("Olaf","Kowal",22,77,177,4234423,"budowa mostów",3)
s1.print_osoba()
s1.print_student()
print(f"kolor oczu: {s1.kolor_oczu}")
print(f"wiek za 10 lat: {s1.wiekza10lat()}")
print(f"czy osoba jest pracownikiem? {s1.czypracownik()}")

#stwórz dwie instancje klasy Student (obiekty)
#1. Student pracownik  (ale nie sportowiec)
#2. Student sportowiec (ale nie pracownik)

print("_____________________________________________________")
s2 = Student("Olga","Kowal",21,56,170,85676,"informatyka",2,"XYZ","Junior Developer",1,3200)
s2.print_osoba()
s2.print_pracownik()
s2.print_student()
print(f"wiek za 10 lat: {s2.wiekza10lat()} lat/a")
print(f"czy osoba jest pracownikiem? {s2.czypracownik()}")
print(f"zapotrzebowanie energetyczne: {s2.policzppm('k'):.2f} kcal")

print("_____________________________________________________")
s3 = Student("Robert","Nowak",22,71,172,75343,"informatyka",3, dycyplina="biegi ultra",
             lata_upr=5,best_wynik="102km  18h 45min 12s")
s3.print_osoba()
s3.print_student()
s3.infosport()
print(f"wiek za 10 lat: {s3.wiekza10lat()} lat/a")
print(f"czy osoba jest pracownikiem? {s3.czypracownik()}")
print(f"bmi ciała wynosi: {s3.bmi():.2f}, opis: {s3.opis_bmi()}")
print(f"zapotrzebowanie energetyczne: {s3.policzppm('m'):.2f} kcal")

