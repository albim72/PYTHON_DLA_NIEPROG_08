class Osoba:

    def __init__(self,imie,nazwisko,wiek,waga,wzrost):
        self.imie = imie
        self.nazwisko = nazwisko
        self.wiek = wiek
        self.waga = waga
        self.wzrost = wzrost
        self.kolor_oczu = "brązowe"
        self._info()

    def _info(self):
        print("tworzenie nowego obiektu -> Osoba....")

    def print_osoba(self):
        print(f"osoba -> imię: {self.imie}, nazwisko: {self.nazwisko}, wiek: {self.wiek} lat, "
              f"waga: {self.waga} kg, wzrost: {self.wzrost} cm")

    def wiekza10lat(self):
        return self.wiek + 10

    def czypracownik(self):
        return False

p1 = Osoba("Jan","Kot",39,89,174)
p1.print_osoba()
print(f"kolor oczu: {p1.kolor_oczu}")
print(f"wiek za 10 lat: {p1.wiekza10lat()}")
print(f"czy osoba jest pracownikiem? {p1.czypracownik()}")

print("***************************************************")
p2 = Osoba("Aneta","Nowak",28,56,167)
p2.print_osoba()
p2.kolor_oczu = "niebieskie"
print(f"kolor oczu: {p2.kolor_oczu}")
print(f"wiek za 10 lat: {p2.wiekza10lat()}")
print(f"czy osoba jest pracownikiem? {p2.czypracownik()}")

print("***************************************************")
p3 = Osoba("Olga","Knot",45,61,172)
p3.print_osoba()
print(f"kolor oczu: {p3.kolor_oczu}")
print(f"wiek za 10 lat: {p3.wiekza10lat()}")
print(f"czy osoba jest pracownikiem? {p3.czypracownik()}")