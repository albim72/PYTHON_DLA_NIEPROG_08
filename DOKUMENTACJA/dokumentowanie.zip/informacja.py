"""
Program pokazuje w jaki sposób przebiega proces dokumentowania
To jest komentarz dokuemntacyjny wieloliniowy
Sprawdźmy jak wygląda generowanie dokumentacji....
"""

a = 7
print(a)

"""
bardzo krótkie działanie 
wyświetlemnie zmiennej a
"""