import informacja

str_  = repr(informacja.__doc__)
print(str_)

def palindrome(word):
    """
    Zwraca wartość True
    jeśli podane słowo jest palindromem
    """
    return word == word[::-1]
assert palindrome('kajak')
assert not palindrome('banan')

print(repr(palindrome.__doc__))

f = open("message.txt","a",encoding='utf-8')
f.write(str_)

f = open("message.rtf","a",encoding='utf-8')
f.write(str_)

f = open("message.pdf","a",encoding='utf-8')
f.write(str_)