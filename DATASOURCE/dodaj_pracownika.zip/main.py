#nowy rekord
from dodawanie_prac import dodaj_nowego_pracownika

nowyprac = {
            "imie": "Benedykt",
            "nazwisko": "Kowalski",
            "stanowisko": "kierowca",
            "lata_pracy": 12,
            "email": "benekkow@firma.pl"
}

dodaj_nowego_pracownika(nowyprac)