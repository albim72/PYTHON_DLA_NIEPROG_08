import json

json_str = '{"name":"Jack","secondname":"Sparrow","ship":"Black Pearl"}'

print(json_str)
print(type(json_str))

json_dict = json.loads(json_str) #ładowanie żródła json do kolekcji Python

print(json_dict)
print(type(json_dict))
print(json_dict['ship'])

autokomis = {
    "marka":"Jeep",
    "model":"Cherokee",
    "rocznik":2018,
    "poj":4.6
}

jsonauto = json.dumps(autokomis,indent=4)

print(jsonauto)
print(type(jsonauto))

with open("autokomis.json","w") as f:
    f.write(jsonauto)

with open("autokomis.json","r") as f:
    auto_dict = json.load(f)

print(auto_dict)

print("**************************************************")

info = '{"organizacja":"Fundacja BIOTECH","miasto":"Krosno","kraj":"Polska"}'
extra = {"id":53445,"zakres":"sztuczna inteligencja"}

#uzupełnij źródło JSON o pola zawarte w słowniku extra

z = json.loads(info)
z.update(extra)
info_new = json.dumps(z,indent=4)
print(info_new)

