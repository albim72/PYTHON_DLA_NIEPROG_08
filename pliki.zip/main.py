import os

#strumień danych
f = open("dane.txt","r",encoding="utf-8")
print(f.readline())
print(f.readline())
print(f.readline())
print(f.readline())
f.close()

print("____________________________________")
f = open("dane.txt","r",encoding="utf-8")
print(f.read())
f.close()

print("____________________________________")
f = open("dane.txt","r",encoding="utf-8")
for linia in f:
    print(linia)
f.close()

#tworzenie nowego pliku z zawartością
print("____________________________________")
f = open("waznedane.txt","a",encoding="utf-8")
f.write("to jest ważna wiadomość.\n")
f.close()

print("____________________________________")
f = open("waznedane.txt","r",encoding="utf-8")
print(f.read())
f.close()

if os.path.exists("waznedane.txt"):
    os.remove("waznedane.txt")
    print("plik został usunięty")
else:
    print("plik nie istnieje!")