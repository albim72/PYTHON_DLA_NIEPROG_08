class MyCustomError(Exception):

    def __init__(self,*args):
        if args:
            self.message = args[0]
        else:
            self.message = None

    def __str__(self):
        print("wywołanie konstruktora __str__()")
        if self.message:
            return f"MyCustomError, {self.message}"
        else:
            return "MyCustomError jest w użyciu"

raise MyCustomError("mamy spory problem....")