class NieparzystaError(Exception):

    def __init__(self,n):
        self.n = n

    def __str__(self):
        return f"Zadana wartość {self.n} jest liczbą nieparzystą. Wstawianie danych do listy zostało przerwane!"

