#zbuduj pustą listę o nazwie punkty[], do której będziesz wprowadzać iteracyjnie kolejne wartości liczbowe (int)
#za pomocą funkcji input(), wprowadzanie wartości ma zostać przerwane w momencie wprowadzenia liczby nieparzystej
#w momencie wprowadzenia takiej wartości program ma wygenerować wyjątek opisany własną klasą błędu
#o nazwie NieparzystyError() -> Stórz własną kalsę błędu pobierającą zadaną wartość  i wyświetlającą
#tą wartość w komunikacie, który zakończy budowę listy.
#mechanizm ładowania danych do listy może być opisany funckją
from parzystalista import parzysta_lista
from nieperror import NieparzystaError

punkty = []
try:
    parzysta_lista(punkty)
except NieparzystaError as e:
    print(e)
finally:
    print(punkty)

