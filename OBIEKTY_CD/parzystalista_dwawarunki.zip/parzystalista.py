import math

from nieperror import NieparzystaError

def parzysta_lista(lista):

    while True:
        print("Podaj dowolną wartość parzystą -> zostanie dopisana do listy. "
              "Podanie wartości nieparzystej przerwie wstawianie danych do listy: ")
        pkt = int(input())
        pl = math.sqrt(pkt)

        if pkt%2 != 0 and pl - int(pl) != 0:
                raise NieparzystaError(pkt)
        lista.append(pkt)
