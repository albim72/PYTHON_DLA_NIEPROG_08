class SilniaError(Exception):

    def __init__(self,n):
        self.n = n

    def __str__(self):
        return f"Zadana wartość {self.n} jest liczbą ujemną. Znajduje się poza zakresem dziedziny funkcji silnia." \
               f"\nDziedzina funkcji silnia to liczby całkowite nieujemne."