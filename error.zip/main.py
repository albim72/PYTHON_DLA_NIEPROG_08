try:
    print(x)
except NameError:
    print("x nie istnieje!")
except:
    print("nieokreślony błąd")
finally:
    x=10
    print(x)

print("ciąg dalszy programu")