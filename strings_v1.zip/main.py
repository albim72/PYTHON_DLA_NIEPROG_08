str_ = "Mecz miesiąca:\nKlub sportowy: \"Orły Wisła\" - \tTrener: Jan Kot\nlokalizacja: Janowiec\n" \
       "vs\nKlub sportowy: \"Biedronka Niwa\" - \tTrener: Adam Knot\nlokalizacja: Niwa\n"

print(str_)

