from wrappers import startstop, pomiarczasu, sleep, debug

def zawijanie():
    print("Zawijanie czekoladek w sreberka...")

zaw = startstop(zawijanie)()

@startstop
def dmuchanie():
    print("dmuchanie baloników urodzinowych....")

dmuchanie()

@sleep
@pomiarczasu
def sumujtablice():
    sum([i**2 for i in range(1000000)])

sumujtablice()

@sleep
def dzialaj():
    print(f"funkcja działająca z opóźnieniem")

dzialaj()

@debug
def testowa():
    print("krótki test")

testowa()