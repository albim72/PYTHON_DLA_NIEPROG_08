import time
def startstop(funkcja):
    def wrapper():
        print("start procesu....")
        funkcja()
        print("kończenie procesu....")
    return wrapper

def pomiarczasu(funkcja):
    def wrapper():
        starttime = time.perf_counter()
        funkcja()
        endtime = time.perf_counter()
        print(f"czas wykonania funkcji: {endtime-starttime} s")
    return wrapper

def sleep(funkcja):
    def wrapper():
        time.sleep(8)
        return funkcja()
    return wrapper

def debug(funkcja):
    def wrapper():
        print(f"wywołana funckja: {funkcja.__name__}")
    return wrapper

