import numpy as np
import pandas as pd

s = pd.Series([1,4,5,np.nan,19,27])
print(s)

daty = pd.date_range("20220812",periods=6)
print(daty)

df = pd.DataFrame(np.random.randn(6,4),index=daty, columns=list('ABCD'))
print(df)

print(df.head(3))
print(df.tail(3))

macierz = df.to_numpy()
print(macierz)


print(df.describe())

print(df.sort_index(axis=1,ascending=False))

print(df['A'])

print(df.loc[daty[0]])