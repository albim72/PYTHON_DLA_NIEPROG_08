import numpy as np

a = np.array([1,3,7,11,2,34,9])
print(a)
print(type(a))

b = np.array([[1,2,3],[4,5,6],[7,8,9]])
print(b)
print(type(b))

c = np.zeros(6, dtype=int)
print(c)

d = np.arange(8)
print(d)

e = np.arange(2,12,2)
print(e)

f = np.linspace(0,10,num=5)
print(f)

tab = np.array([6,1,3,4,9,2,11,4,17,8,22,10])
print(tab)

print(np.sort(tab))

tabr = tab.reshape(4,3)
print(tabr)



