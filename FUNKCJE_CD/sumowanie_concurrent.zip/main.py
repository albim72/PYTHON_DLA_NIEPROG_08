#napisz funkcję która znajdzie sumę wszystkich liczb pierwszych z zadanego przeziału (min,max)
#stwórz listę krotek zawierjących kolekcję przedziałów
#wykonaj tę funkcję na liście
#wyznacz czas wykonania funkcji
import time
import concurrent.futures
from sumowanie import find_prime_numbers_sum

numbers = [(1,10000),(3,50000),(5000,100000),(4,900),(800,15000)]

def sync():

    start_time = time.time()

    for pair in numbers:
        prime_sum = find_prime_numbers_sum(*pair)
        print(prime_sum)

    end_time = time.time()
    print(f"Całkowity czas zliczenia sumy synchronicznie wynosi: {end_time - start_time:2f} s")

def run_heavy_function(params):
    return find_prime_numbers_sum(*params)

def main():
    start_time = time.time()
    with concurrent.futures.ProcessPoolExecutor(max_workers=5) as executor:
        result = executor.map(run_heavy_function,numbers)
    print(list(result))
    end_time = time.time()
    print(f"Całkowity czas wykonania wszystkich wątków wynosi: {end_time - start_time:2f} s")

if __name__ == '__main__':
    sync()
    main()
