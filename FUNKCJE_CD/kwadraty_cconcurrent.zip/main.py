#stwórz listę wartości całkowitych, zbuduj funkcję kwadrat, wyświetl wyniki podnoszenia każdej wartości do kawdratu
#w trybie asychronicznym

from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
from concurrent.futures import as_completed

values = [34,2,8,-3,9,0,19,111,2]

def kwadrat(n):
    return n**2

def main():
    with ProcessPoolExecutor(max_workers=3) as executor:
        results = executor.map(kwadrat,values)
    for result in results:
        print(result)

if __name__ == '__main__':
    main()