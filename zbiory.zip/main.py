drzewa = {"buk","dąb","jodła","jesion","baobab","jabłoń"}
print(drzewa)
print(drzewa)
print(drzewa)
print("_____________________________________")
for d in drzewa:
    print(d)

print("_____________________________________")

print("jesion" in drzewa)
print("osika" in drzewa)

drzewa.add("osika")
print(drzewa)

drzewa.update(["wierzba","sosna","topola","jodła kaukaska"])
print(drzewa)

drzewa.add("dąb")
print(drzewa)

drzewa.remove("osika")
print(drzewa)

drzewa.discard("jojoba")
print(drzewa)

drzewa.discard("sosna")
print(drzewa)

dm = drzewa.pop()
print(dm)
print(drzewa)