print("pierwszy komunikat programu....")
a = "to jest drugi komunikat programu...."
print(a)

b = 67
print(b)
print(type(b))

b = "trzeci"
print(b)
print(type(b))

c:float
c = 11.45

print(c)
print(type(c))

c = "jedenaście"
print(c)
print(type(c))

d = 78

print("kolekcja:",a,b,c,d,sep=" -- ")
print("konkatenacja: " + b + ", " + c + ", " + str(d))

#komentarz podstawowy
#druga linia komentarza....
#trzecia linia komentarza....   kopiowanie linii CTRL+D

"""
komentarz dokumentacyjny - -wieloliniowy
druga linia
"""

"""
drugi komentarz.....
druga linia
"""

y = 12.3457
print(8*y)

x = "17.88"
print(7*x)

print(7*float(x))
print(7*eval(x))

k = True
print(8*k)

g1 = 10
g2 = 11

print(g1+g2, g1-g2, g1*g2, g1/g2, g1**g2)

u = 12
u += 1
print(u)

s = "lajkonik"
print(s)
print(s[0])
print(s[1])
print(s[2:5])
print(s[3:])
print(s[:5])
print(s[-1])
print(s[-2])

#standardowe funkcje matematyczne
print(round(10.50))
print(round(10.50,1))
print(round(10.51))

print(pow(5,4))
print(5**6)




