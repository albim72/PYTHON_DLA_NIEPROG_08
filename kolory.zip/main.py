class Kolor:

    paleta = "paleta X"

    #reprezentacja stanu -> konstruktor klasy
    def __init__(self,id,nazwa):
        self.idkoloru = id
        self.nazwa = nazwa
        self.liczba_odcieni = 3
        self.model_palety = "RGB"

    #definicja zachowania -> funkcje klasy -> metody
    def print_kolor(self):
        print(f"idkoloru: {self.idkoloru}, nazwa koloru: {self.nazwa}, paleta: {self.paleta},"
              f" liczba odcieni: {self.liczba_odcieni}, model palety koloru: {self.model_palety}")

    def set_lodcieni(self,_lodcieni):
        self.liczba_odcieni = _lodcieni

    def set_model(self,_model):
        self.model_palety = _model

    def get_paleta(self):
        return f"nazwa palety: {self.paleta}"
#rozbuduj konstruktor o model palety koloru (RGB,CMYK,Lab) -> domyślna -> RGB
#uzupełnij metodę print_kolor o wyświetlanie modelu koloru....
#wyświetl pełną opcję opisową dla wszystkich instancji


k1 = Kolor(1,"Czerwony")
k2 = Kolor(2,"Zielony")

k1.print_kolor()
k2.print_kolor()

k3 = Kolor(213,"Navy")
k3.paleta = "paleta EXT"
k3.set_lodcieni(4)
k3.set_model("CMYK")
k3.print_kolor()

k4 = Kolor(123,"Różowy")
k4.print_kolor()
print(k4.get_paleta())
