class Resistor:

    def __init__(self,ohms):
        self.ohms = ohms
        self.voltage = 0 #napięcie prądu [V]
        self.current = 0 #natężene prądu


