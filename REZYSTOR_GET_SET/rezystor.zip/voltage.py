from resistor import Resistor

class VoltageResistance(Resistor):

    def __init__(self,ohms):
        super().__init__(ohms)
        self._voltage = 0

    #nowy schemt budowy funckji typu get
    @property
    def voltage(self):
        return self._voltage

    # nowy schemt budowy funckji typu set
    @voltage.setter
    def voltage(self,voltage):
        self._voltage = voltage
        self.current = self._voltage/self.ohms

    @property
    def ohms(self):
        return self._ohms

    @ohms.setter
    def ohms(self,ohms):
        if ohms <=0:
            raise ValueError(f'Wartość opornika nie może być ujemna lub równa 0')
        self._ohms = ohms


