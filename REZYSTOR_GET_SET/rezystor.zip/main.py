from odlresistor import OldResistor
from resistor import Resistor
from voltage import VoltageResistance


r0 = OldResistor(50e3)
print(f"Przed zmianą opornika: {r0.get_ohms()} omów")

r0.set_ohms(10e3)
print(f"Po zmianie opornika: {r0.get_ohms()} omów")

r0.set_ohms(r0.get_ohms() - 4e3)
print(f"Po kolejnej zmianie opornika: {r0.get_ohms()} omów")

print("******************************")

r1 = Resistor(56e3)
r1.ohms = 10e3
print(f"Dane układu\n{r1.ohms} omów\n{r1.voltage} Volt\n{r1.current} Amper")

print("******************************")

r2 = VoltageResistance(2e3)
print(f'Natężenie prądu przed zmianą: {r2.current:.2f} amperów')
r2.voltage = 10
print(f'Natężenie prądu po zmianie: {r2.current:.2f} amperów')
r2.voltage = 220
print(f'Natężenie prądu po kolejnej zmianie: {r2.current:.2f} amperów')

# w klasie VoltageResistance dopisz funkcje get i set dla oporności (ohms)
#zmień wartość opornika na 7e4 omów i zadaj natężenie prądu 230V
# wypisz wszystkie parametry za pomocą getów....
print("***********************************************")
r3 = VoltageResistance(2e3)
print(f'Napięcie prądu przed zmianą: {r3.voltage} volt,\n'
      f'Natężenie prądu przed zmianą: {r3.current:.2f} amperów\n'
      f'Oporność: {r3.ohms:.2f} omów')
print("***********************************************")
try:
    r3.ohms = 6
    r3.voltage = 230

    print(f'Napięcie prądu po zmianie: {r3.voltage} volt,\n'
          f'Natężenie prądu po zmianie: {r3.current:.2f} amperów\n'
          f'Oporność: {r3.ohms:.2f} omów')
except ValueError as e:
    print(e)

