liczby = [45,67,1001,-899,2012,30,0,99,8,1,-4,800,120,456]

def pokaz_stat(lista):
    minimum = min(lista)
    maksimum = max(lista)
    rozstep = maksimum - minimum
    return minimum, maksimum, rozstep

wynik = pokaz_stat(liczby)
print(wynik)
print(type(wynik))

mini, maxi, roz = pokaz_stat(liczby)
print(f"wartość maksymalna: {maxi}, wartość minimalna: {mini}, rozstęp: {roz}")