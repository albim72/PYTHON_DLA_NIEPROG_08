animal = ("pies","kot","papuga","szczur","królik","szynszyla","pies","pies")

print(animal)
print(animal[0])
print(animal[2:5])
print(animal[-2])

print(animal.index("papuga"))
print(animal.count("papuga"))
print(animal.count("pies"))

for a in animal:
    print(a)

print(len(animal))

if "papuga" in animal:
    print("Tak papuga jest zwierzeciem!")

if "budynek" not in animal:
    print("OK")
else:
    print("budynek nie powinien zawierać się w krotce...")

anim2 = ("pająk","ryba")
animal = animal + anim2
print(animal)

mojakrotka = tuple(["obiekt45",45,67.88,True,"Toruń",900,False])
print(mojakrotka)

#zmodyfikuj zwartość krotki w następujący sposób: usuń wartość 45, zamień Toruń -> Gdańsk
#dodaj na końcu krotki 1002

#zamień krotkę na listę -> list(mojakrotka)
#zmodyfikuj
#z powrotem przekształć w krotkę

mojalista = list(mojakrotka)
print(mojalista)

mojalista.remove(45)
inml = mojalista.index("Toruń")
mojalista[inml] = "Gdańsk"
mojalista.append(1002)

mojakrotka = tuple(mojalista)
print(mojakrotka)

samochod = ("Audi","Q7",4.6,"czarny",2019,56700)

(marka,model,poj,kolor,rok,przebieg) = samochod

print(marka)
print(model)
print(poj)
print(kolor)
print(rok)
print(przebieg)

egzamin = [("Tomasz","Kos",45),("Olga","Kłos",55),("Robert","Nowak",47),("Aneta","Kowal",87)]
opis = ([4,6,7,12,3,4],["Ola","Paweł","Leon","Hilary"],["czerwony","czarny","zielony"])