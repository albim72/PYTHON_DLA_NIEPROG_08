a = 1
b = 1

if a>b:
    print("a jest większe od b!")
elif a==1 and b==1:
    print("a i b to jedynki")
elif a==b:
    print("a jest równe b")
else:
    print("a jest mniejsze niż b!")

#iteracja

i = 1
while i<6:
    print(i)
    if i==3:
        break
    i += 1
else:
    print("najwyższa wartość i: ", i)
#komentowanie wybranych linii -> CTRL+/

#print("najwyższa wartość i: ", i)

owoce = ["jabłko","kiwi","malina","truskawka","granat","śliwka węgierka","banan"]

print("_____________________________________________________________")

for owoc in owoce:
    print(owoc)

print("_____________________________________________________________")

#napisz pętlę która przetanie wyświetlać owoce gdy trafi na granat!

for owoc in owoce:

    if owoc == "granat":
        break
    print(owoc)

print("_____________________________________________________________")

cechy = ["kolorowy","elegancki","brudny","obskurny","piękny","kosztowny"]
obiekty = ["budynek","płaszcz","ogród","przystanek","samochód"]

for cecha in cechy:
    for obiekt in obiekty:
        print(cecha,obiekt)