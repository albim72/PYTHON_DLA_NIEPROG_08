def witaj():
    print("witaj użytkowniku")
    print("opłać abonament")
    print("zaloguj się")

witaj()
witaj()
#wykonaj funkcję 55 razy

for _ in range(55):
    witaj()

nb = [1,2,34,5,6,77,8,11,23,4,56,7,89,11]

#wyświetl dane od wartości z indeksem 1 do wartości z imndeksem 11 co drugą wartość

for i in range(1,12,2):
    print(nb[i])

print("___________________________")

def obywatel(nrtelefonu,kraj="Polska"):
    print("pochodzę z kraju:",kraj,", numer telefonu:",nrtelefonu)


obywatel(5345345,"Włochy")
obywatel(546765765,"Irlandia")
obywatel(412234345,"Urugwaj")
obywatel(43654756,"Wietnam")
obywatel(55564654)


def fx(n):
    return 2**n

f = 11
def policz(a,b,x):
    global f
    f = (a+b)*x + f + fx(b)
    return f

print(policz(3,12,9.9))
print(f)

