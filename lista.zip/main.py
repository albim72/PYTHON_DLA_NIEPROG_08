country = ["Polska", "Niemcy","Norwegia","Hiszpania","Kanada"]
print(country)

print(country[0])
print(country[2:4])

country.append("Turcja")
print(country)

country[2] = "Szwecja"
print(country)

#sortowanie listy
country.sort()
print(country)

for cn in country:
    print(cn)

country.reverse()
print(country)

country.sort(reverse=True)
print(country)

liczby = [34,0,12,-5,-7,122,1000,94,12,12,0,56,7,0]
print(liczby)
liczby.sort(reverse=True)
print(liczby)

print(liczby[3:7])
liczby.remove(12)
print(liczby)
i94 = liczby.index(94)
del liczby[i94]
print(liczby)

print(liczby.count(12))

sklepzoo = [["pies","kot","papuga","szczur"],[7600,2500,8700,100]]

print(sklepzoo)
print(sklepzoo[0])
print(sklepzoo[0][0]," - ",sklepzoo[1][0], "zł")

miasto = ["Kielce","Rzeszów","Opole","Poznań"]
stolica = ["Warszawa","Rzym"]

miasto = miasto + stolica
print(miasto)

miasto = miasto + ["Zamość","Koszalin"]
print(miasto)

miasto = 4*miasto
print(miasto)

litery = ['a','b','c','d','e','f','g','h']

print("litery przed zmianą:",litery)
litery[2:7] = [99,101,202]
print("litery po zmianie:",litery)

litery_m  = litery
litery_p = list(litery)
litery_q = litery[:]
print("litery przed zmianą:",litery)
print("litery_m przed zmianą:",litery_m)
print("litery_p przed zmianą:",litery_p)
print("litery_q przed zmianą:",litery_q)

litery[:] = [1002, 1007, 1123, 1178]
print("litery po zmianie:",litery)
print("litery_m po zmianie:",litery_m)
print("litery_p po zmianie:",litery_p)
print("litery_q po zmianie:",litery_q)

#zadanie: stwórz dwie listy parz i nieparz i przekaż jako zawartość wartości:
#parz -> nazwy kolorów z listy kolory z pozycji parzystych
#nieparz -> nazwy kolorów z listy kolory z pozycji nieparzystych

kolory = ['czerwony','żółty','zielony','pomarańczowy','czarny','biały']

# nazwa[n:m:r] -> n początek listy, m konic listy, r krok

parz = kolory[::2]
nieparz = kolory[1::2]

print(parz)
print(nieparz)

#odwróć kolejność liter wyrazach:
w1 = "kajak"
w2 = "pomarańcza"

odw1 = w1[::-1]
odw2 = w2[::-1]

print(w1," -> ",odw1)
print(w2," -> ",odw2)

