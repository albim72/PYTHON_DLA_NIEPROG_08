def dzielenie(x,y):
    try:
        wynik = x/y
    except ZeroDivisionError:
        print("dzielenie przez 0!")
    except NameError:
        print("brak danych")
    except TypeError:
        print("do funkcji wstawiamy tylko liczby!")
    else:
        print(f"wynik dzielenia: {wynik}")
    finally:
        print("policzmy coś jeszcze")

dzielenie(1,1)
dzielenie(1,0)
dzielenie(0,0)
dzielenie(45,23)
dzielenie(0,12)
dzielenie(-89,0.67)
dzielenie(1,False)
dzielenie("gggg",1000)

#pomiń parametr y w wywpłaniu funkcji dzielenie i sprawdź działanie
#dokonaj obsługi błędu który wyskoczy
try:
    dzielenie(99)
except TypeError:
    print("zbyt mała liczba argumentów....")

