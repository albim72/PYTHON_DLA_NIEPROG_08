def filtrowanie(tablica,test):
    passed = []
    for element in tablica:
        if(test(element)):
            passed.append(element)
    return passed


def mapowanie(tablica,transformacja):
    zamapowane = []
    for element in tablica:
        zamapowane.append(transformacja(element))
    return zamapowane

def imie(funkcja,imie):
    return funkcja(imie)

def rejestracja(funkcja,*dane):
    return funkcja(*dane)

def nowypojazd(klasa,*args):
    return klasa(*args)

def egzamin(jesli):
    def gratulacje():
        return "Gratulacje zdanego egzaminu!"
    def przykro():
        return "Przykro mi. Natępnym razem będzie lepiej!"
    if jesli == "tak":
        return gratulacje
    else:
        return przykro



