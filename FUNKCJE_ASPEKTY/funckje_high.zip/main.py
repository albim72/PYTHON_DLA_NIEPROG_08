from funkcje_high import filtrowanie,mapowanie,imie,rejestracja,nowypojazd,egzamin

def czymojaliczba(nb):
    return nb >= 10
lnb = [1,5,11,3,22,7,80]
print(filtrowanie(lnb,czymojaliczba))

def policz(n):
    return (n+2)**3

print(mapowanie(lnb,policz))

#napisz funckję wyższego rzędu imie() /funkcje_high/ wywołującą funckję powitanie() /main/,
#funckja imię ma przekazywać dowolne imię wywoływać funckję powitanie,
# która ma wypisać printem "Miło Cię widzieć {Imię}!"

def powitanie(name):
    return f"Miło Cię widzieć {name}!"

print(imie(powitanie,"Szymon"))

#zmodyfikuj funckję imie - pod nazwą rejestracja, gdzie wywołasz dowolną funkcję z dolowną liczbą paramtrów
#napisz funcję uczestni z wybranymi danymi uczestnika konferencji i wypisz te dane za pomocą
#funkcji rejestracja

def uczestnik(imie,nazwisko,asocjacja,nocleg,rodzaj):
    return f"Uczestnik konferencji: {imie} {nazwisko}, {asocjacja}, nocleg: {nocleg}, rodzaj: {rodzaj}"

print(rejestracja(uczestnik,"Maciej","Knot","Politechnika Lubelska",True,"Prelegent"))

class Pojazd:
    def __init__(self,id,marka,rocznik):
        self.id = id
        self.marka = marka
        self.rocznik = rocznik

    @property
    def marka(self):
        return self.marka

    @marka.setter
    def marka(self,marka):
        self._marka = marka

p: object = nowypojazd(Pojazd,4,"Jeep",2017)
print(p)

eg = input("Czy egzamin jest zdany? (tak/nie): ")
print(egzamin(eg)())
