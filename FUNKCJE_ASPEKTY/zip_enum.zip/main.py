nb = [1,2,3,4,5]
nbstr = ['jeden','dwa','trzy','cztery']
nbstreng = ('one','two','three','four','five')

wynik = zip()
lista_wynikowa = list(wynik)
print(lista_wynikowa)

wynik = zip(nb, nbstr,nbstreng)
lista_wynikowa = list(wynik)
print(lista_wynikowa)

print("***************************")

sklep = ['chleb','mleko','masło','pomidor']
enumsklep = enumerate(sklep)
print(list(enumsklep))
print(type(enumsklep))

enumsklep = enumerate(sklep,11)
print(list(enumsklep))

print("***************************")

for i,produkt in enumerate(sklep,1000):
    print(f"{i}:{produkt}")