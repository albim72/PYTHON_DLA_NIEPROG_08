def liczby():
    for i in range(11):
        yield i

for wart in liczby():
    print(wart)


def wznowienia():

    print("wstrzymanie działania")
    yield 1
    print("wznowienie działania")

    print("wstrzymanie działania")
    yield 99
    print("wznowienie działania")

    print("wstrzymanie działania")
    yield 202
    print("wznowienie działania")

for i in wznowienia():
    print(f"Zwrócono wartość: {i}")


def mojgenerator():
    for i in range(5):
        if i == 3:
            return
        else:
            yield i


for x in mojgenerator():
    print(x)