print("witaj w programie")
print("podaj swoje imię: ")
imie = input()
print("Miło Cię widzieć " + imie)
print("Liczba liter w imieniu: " + str(len(imie)))

wiek = int(input("Podaj swój wiek: "))
print("Za 5 lat będziesz mieć: " + str(wiek+5) + " lat/a")
