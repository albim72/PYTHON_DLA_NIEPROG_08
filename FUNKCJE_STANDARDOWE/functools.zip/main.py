from functools import partial,partialmethod,cmp_to_key
import operator

#przykład nr 1
def specpower(a,b,v):
    return (a+v)**(b-v)

sp2 = partial(specpower,b=2)
sp4 = partial(specpower,b=4)
sp_5 = partial(specpower,5)

print(specpower(2,6,3))
print(sp2(4,v=1))
print(sp2(7,v=2))
print(sp_5(2,5))

print(f"funkcja użyta w funkcji częściowej sp2: {sp2.func}")
print(f"funkcja użyta w funkcji częściowej sp4: {sp4.func}")
print(f"funkcja użyta w funkcji częściowej sp_5: {sp_5.func}")

#przykład nr 2

class Kolory:
    def __init__(self):
        self.color = 'black'

    def _color(self,type):
        self.color = type

    set_red = partialmethod(_color,type='red')
    set_blue = partialmethod(_color,type='blue')
    set_green = partialmethod(_color,type='green')

k1 = Kolory()
print(k1.color)

k1.set_blue()
print(k1.color)

#przykład nr 3
#funkcja sortująca po ostatnim znaku

def cmp_fun(a,b):
    if a[-1] > b[-1]:
        return 1
    elif a[-1] < b[-1]:
        return -1
    else:
        return 0

lista = ['Ultra','Trail','Małopolska','cab','xyz']
sl = sorted(lista, key=cmp_to_key(cmp_fun))
print(sl)

#przykład nr 3
#użycie biblioteki operator
a = 7
b = 11

print(f"dodawanie liczb - operator add(): {operator.add(a,b)}")
print(f"odejmowanie liczb - operator sub(): {operator.sub(a,b)}")
print(f"mnożenie liczb - operator mul(): {operator.mul(a,b)}")