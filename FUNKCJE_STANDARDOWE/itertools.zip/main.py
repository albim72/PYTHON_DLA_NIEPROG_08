import itertools
from itertools import product

#zadanie 1
for i in itertools.count(5,5):
    if i == 35:
        break
    else:
        print(i,end=" ")

#zadanie 2

print("\n***********************************")
count = 0
for i in itertools.cycle('ABC'):
    if count > 7:
        break
    else:
        print(i,end = " ")
        count += 1

#zadanie 3

print("\n***********************************")
opcja = ['Trening','Siła','Walka']
iterators = itertools.cycle(opcja)

for i in range(10):
    print(next(iterators), end = " ")

#zadanie 4

print("\n***********************************")

print("wyświetlanie liczby przez funkcję repeat(): ")
print(list(itertools.repeat(25,8)))

#zadanie 5

print("\n***********************************")

print("iloczyn kartezjański z użyciem repeat(): ")
print(list(product([1,2],repeat = 2)))

print("iloczyn kartezjański kontenerów: ")
print(list(product(opcja,'2')))

print("iloczyn kartezjański kontenerów: ")
print(list(product('ABC',[3,5,7])))