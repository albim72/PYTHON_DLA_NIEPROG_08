import datetime
from datetime import date
import time

print(f"Minimalny rok daty:{datetime.MINYEAR}")
print(f"Maksymalny rok daty:{datetime.MAXYEAR}")

print(f"Zadana data to: {date(1995,12,23)}")
print(f"Dziś jest: {date.today()}")

print(f"dolna granica date: {date.min}")
print(f"górna granica date: {date.max}")

print(f"data liczona od Epoki: {date.fromtimestamp(476098655)}") #zadany czas w ms
print(f"data liczona od Epoki: {date.fromtimestamp(0)}") #zadany czas w ms
print(f"data liczona od Epoki: {date.fromtimestamp(4760986557)}") #zadany czas w ms

obj = time.gmtime(0)
epoka = time.asctime(obj)
print(f"epoka: {epoka}")

time_sec = time.time()
print(f"czas w s od epoki: {time_sec}")

