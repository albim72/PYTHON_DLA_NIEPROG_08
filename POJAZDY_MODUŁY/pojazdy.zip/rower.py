from ipojazd import IPojazd
from marka import Marka

class Rower(IPojazd,Marka):

    # def __init__(self,nazwa,model,rocznik):
    #     Marka.__init__(self,nazwa,model,rocznik)

    def pokaz_naped(self):
        return "korba"

    def predkosc_max(self):
        return 60

    def opis_roweru(self):
        print(f"Rower -> marka: {self.nazwa}, model: {self.model}, rocznik: {self.rocznik}")