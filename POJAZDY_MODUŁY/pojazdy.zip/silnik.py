class Silnik:

    def __init__(self,rodzaj,poj):
        self.rodzaj = rodzaj
        self.poj = poj
