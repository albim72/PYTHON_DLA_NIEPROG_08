from ipojazd import IPojazd
from silnik import Silnik
from marka import Marka

class Osobowy(IPojazd, Silnik, Marka):

    def __init__(self,rodzaj,poj,nazwa,model,rocznik):
        Silnik.__init__(self,rodzaj,poj)
        Marka.__init__(self,nazwa,model,rocznik)

    def pokaz_naped(self):
        return "silnik spalinowy"

    def predkosc_max(self):
        if self.poj <= 1.0:
            return 140
        elif self.poj <= 1.5:
            return 170
        elif self.poj <= 1.8:
            return 190
        elif self.poj <= 2.2:
            return 210
        elif self.poj <= 3.0:
            return 240
        else:
            return "prędkość większa niż 240"

    def opis_samochodu(self):
        print(f"Samochód osobowy -> marka: {self.nazwa}, model: {self.model}, rocznik: {self.rocznik}, "
              f"rodzaj silnika: {self.rodzaj}, pojemność: {self.poj}")