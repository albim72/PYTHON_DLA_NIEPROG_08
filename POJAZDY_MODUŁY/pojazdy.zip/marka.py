class Marka:

    def __init__(self,nazwa,model,rocznik):
        self.nazwa = nazwa
        self.model = model
        self.rocznik = rocznik


