from abc import ABC, abstractmethod

class IPojazd(ABC):

    @abstractmethod
    def pokaz_naped(self):
        pass

    @abstractmethod
    def predkosc_max(self):
        pass

