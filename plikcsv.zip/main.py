import csv

with open("firma.csv",encoding="utf-8") as pc:
    csv_reader = csv.reader(pc,delimiter=";")
    licznik_wierszy = 0
    for wiersz in csv_reader:
        if licznik_wierszy == 0:
            print(f'Nazwa kolumny: {", ".join(wiersz)}')
        else:
            print(f'\t{wiersz[0]} pracuje na stanowisku: {wiersz[1]} i ma urodziny w misiącu: {wiersz[2]},'
                  f' otrzymuje nagrodę pieniężną: {wiersz[3]} zł')
        licznik_wierszy += 1

    print(f"wczytano {licznik_wierszy} wierszy")
    print(f"wczytano {licznik_wierszy-1} osób")