osoba = {
    "imie":"Karol",
    "nazwisko":"Kot",
    "wiek":35,
    "miasto":"Ustka"
}