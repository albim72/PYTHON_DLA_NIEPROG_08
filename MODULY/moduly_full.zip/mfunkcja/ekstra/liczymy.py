def licz(a,b):
    return a**b -1

def mainlicz(x,y,z):
    return z*licz(x,y)