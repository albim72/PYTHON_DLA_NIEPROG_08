import math

def powitanie(name):
    return f"Miło Cię widzieć {name}!"

def fx(e,x):
    return e*math.exp(3*x)