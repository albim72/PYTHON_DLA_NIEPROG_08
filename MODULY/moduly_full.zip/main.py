#import dane
import dane as dn
from dane import osoba
from moje_funkcje import powitanie, fx
#from miasto import Miasto
from stolica import Stolica,Miasto

from mfunkcja.ekstra.liczymy import mainlicz

print(osoba)
print(powitanie("Wojtek"))
print(powitanie("Telimena"))

print(f"wynik = {fx(4.5,7)}")
print(f"wynik = {fx(0,5)}")
print(f"wynik = {fx(22,0)}")

mt = Miasto(67,"Tarnów","małopolskie")
mt.print_miasto()

st = Stolica(1,"Warszawa","mazowieckie","Jan Nowak")
st.print_miasto()
st.przydentinfo()

print(f"wynik działania -> {mainlicz(3,8,5)}")