import sys

try:
    f = open("waznedane.txt","r")
    s = f.readline()
    i = int(s.strip())
    raise Exception(d=i/0)
    #d = i/0
except OSError as err:
    print(f"błąd systemowy: {err}")
except ValueError:
    print(f"nie można przekonwertować danych do typu integer!")
except Exception as exx:
    print(f"prawdopodobnie dzielenie przez 0, {type(exx)}")
    print(exx.args)
    print(exx)
except:
    print(f"Nieoczekiwany błąd! {sys.exc_info()[0]}")