from prostokat import Prostokat
from trojkat import Trojkat
from trapez import Trapez
from kolo import Kolo

pr = Prostokat(3,6.6)
print(f"pole prostokąta wynosi: {pr.policz_pole():.2f}")

tr = Trojkat(4.5,6)
print(f"pole trójkąta wynosi: {tr.policz_pole():.2f}")

trp = Trapez(7.8,5.6,4.8)
print(f"pole trapezu wynosi: {trp.policz_pole():.2f}")

#Stwórz moduł kolo -> zbuduj klasę Kolo(Figura), policz pole koła dla promienia 5.5
#polekola = math.pi * a**2

kl = Kolo(5.5)
print(f"pole koła wynosi: {kl.policz_pole():.2f}")