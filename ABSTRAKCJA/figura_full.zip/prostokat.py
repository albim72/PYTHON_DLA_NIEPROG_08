from figura import Figura

class Prostokat(Figura):

    def policz_pole(self):
        return self.a*self.b

