from abc import ABC, abstractmethod

class MojaAb():
    pass

class Prototyp(ABC,MojaAb):

    def __init__(self,x):
        self.x = x

    def info(self):
        print("Jest to metoda nieabstrakcyjna klasy abstrakcyjnej")

    @abstractmethod
    def policz(self):
        pass

    @abstractmethod
    def policz_x(self):
        return 5*self.x

class ZwKlasa(Prototyp):

    def __init__(self,x,y):
        super().__init__(x)
        self.y = y

    def policz(self):
        return 1001

    def policz_x(self):
        return super().policz_x() + self.y*3


zk = ZwKlasa(5,78)
print(f"wynik policz() -> {zk.policz()}")
print(f"wynik policz_x() -> {zk.policz_x()}")
