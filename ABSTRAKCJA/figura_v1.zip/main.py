from prostokat import Prostokat
from trojkat import Trojkat

pr = Prostokat(3,6.6)
print(f"pole prostokąta wynosi: {pr.policz_pole():.2f}")

tr = Trojkat(4.5,6)
print(f"pole trójkąta wynosi: {tr.policz_pole():.2f}")