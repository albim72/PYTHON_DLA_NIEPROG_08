class PierwszaKlasa:

    def __init__(self,a,b):
        self.a = a
        self.b = b

    def print_ab(self):
        print(f"a = {self.a}, b = {self.b}")


class DrugaKlasa(PierwszaKlasa):

    def __init__(self,a,b,c):
        super().__init__(a,b)
        self.c = c

    def print_abc(self):
        print(f"a = {self.a}, b = {self.b}, c = {self.c}")

    def policz_sume(self):
        return self.a + self.b + self.c

class GKlasa:

    def __init__(self,g,h):
        self.g = 2.4*g
        self.h = h/3

    def policz_gh(self):
        return (self.g+self.h)**3
#Uzupełnij TrzeciąKlasę o dziedziczenie jako drugiej klasy GKlasa (wielodziedziczenie),
#zmodyfikuj konstruktor TrzeciejKlasy, zmodyfikuj metodę print_abcd -> print_abcdgh (dodaj wyśwetlania
#parametrów g i h
#zmodyfikuj metodę policz_sume() dodając do aktualnej sumy wynik działania metody policz_gh
#sprawdź poprawność definicji obiektów i ich metod

class TrzeciaKlasa(DrugaKlasa,GKlasa):

    def __init__(self,a,b,c,d,g,h):
        DrugaKlasa.__init__(self,a,b,c)
        GKlasa.__init__(self,g,h)
        self.d = d

    def print_abcdgh(self):
        print(f"a = {self.a}, b = {self.b}, c = {self.c}, d = {self.d}, g = {self.g}, h = {self.h}")

    def policz_sume(self):
        return self.a + self.b + self.c + self.d  + self.policz_gh()

#Stwórz po jednym obiekcie dla każdej z klas a następnie wykonaj na nim jak największą
#możliwą liczbę metod (wszystkie dostępne dla obiektu)

print("_________ PierwszaKlasa __________")
pk = PierwszaKlasa(34,6)
pk.print_ab()
print("_________ DrugaKlasa __________")
dk = DrugaKlasa(5,12,8)
dk.print_ab()
dk.print_abc()
print(f"dodawanie a+b+c = {dk.policz_sume()}")
print("_________ TrzeciaKlasa __________")
tk = TrzeciaKlasa(15,11,3,167,12,67)
tk.print_ab()
tk.print_abc()
tk.print_abcdgh()
print(f"dodawanie a+b+c+d+policz_gh = {tk.policz_sume()}")
