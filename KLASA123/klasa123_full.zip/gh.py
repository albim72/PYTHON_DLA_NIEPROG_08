class GKlasa:

    def __init__(self,g,h):
        self.g = 2.4*g
        self.h = h/3

    def policz_gh(self):
        return (self.g+self.h)**3