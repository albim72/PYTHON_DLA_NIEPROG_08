from druga import DrugaKlasa
from gh import GKlasa

class TrzeciaKlasa(DrugaKlasa,GKlasa):

    def __init__(self,a,b,c,d,g,h):
        DrugaKlasa.__init__(self,a,b,c)
        GKlasa.__init__(self,g,h)
        self.d = d

    def print_abcdgh(self):
        print(f"a = {self.a}, b = {self.b}, c = {self.c}, d = {self.d}, g = {self.g}, h = {self.h}")

    def policz_sume(self):
        return self.a + self.b + self.c + self.d  + self.policz_gh()