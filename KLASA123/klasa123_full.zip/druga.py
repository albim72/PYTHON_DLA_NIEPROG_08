from pierwsza import PierwszaKlasa

class DrugaKlasa(PierwszaKlasa):

    def __init__(self,a,b,c):
        super().__init__(a,b)
        self.c = c

    def print_abc(self):
        print(f"a = {self.a}, b = {self.b}, c = {self.c}")

    def policz_sume(self):
        return self.a + self.b + self.c
