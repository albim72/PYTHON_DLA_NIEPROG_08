from druga import PierwszaKlasa, DrugaKlasa
from trzecia import TrzeciaKlasa

print("_________ PierwszaKlasa __________")
pk = PierwszaKlasa(34,6)
pk.print_ab()
print("_________ DrugaKlasa __________")
dk = DrugaKlasa(5,12,8)
dk.print_ab()
dk.print_abc()
print(f"dodawanie a+b+c = {dk.policz_sume()}")
print("_________ TrzeciaKlasa __________")
tk = TrzeciaKlasa(15,11,3,167,12,67)
tk.print_ab()
tk.print_abc()
tk.print_abcdgh()
print(f"dodawanie a+b+c+d+policz_gh = {tk.policz_sume()}")

#przerób projekt klasa123 na modułowy, każdą z klas ulokuj w odebnym pliku pythona  (module)
#zmodyfikuj również plik main.py tworząc odpowiednie odwołania do tych plików
