def miasta(miasto3,miasto2="Zamość",miasto1="Kraków"):
    print("miasto tygodnia:",miasto1,", drugie miejsce:",miasto2,", trzecie miejsce:",miasto3)

miasta("Tarnów","Toruń","Gdańsk")
miasta("Tarnów","Toruń")
miasta("Tarnów")

#wykonaj funkcję miasta -> wstaw pparametry miasto3,miasto1, natomiast miasto2  pobierz jako domyslne

miasta("Rzeszów",None,"Olsztyn")
miasta("Rzeszów",miasto1="Olsztyn")


def zamki(id,*zamek,rabat):
    print("zamek tygodnia:",zamek[0]," - rabat: ",rabat, "zł, drugie miejsce:",zamek[1],", trzecie miejsce:",zamek[2])

zamki(34,"Malbork","Czersk","Olsztyn",rabat=20)
zamki(2,"Janowiec","Malbork","Będzin","Czersk","Olsztyn","Krzyżtopór",rabat=5)

