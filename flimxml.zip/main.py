import xml.sax

from uchwyt import UchwytFilmu
from srednia import get_sredniaodchyl

parser = xml.sax.make_parser()
parser.setFeature(xml.sax.handler.feature_namespaces,0)

handler = UchwytFilmu()

parser.setContentHandler(handler)

parser.parse("filmy.xml")

wypozyczenia = [45,11,123,67,88,90,2,156,234,99,113,665,3,117,88,190,34,266]

longest,*middle,shortest = get_sredniaodchyl(wypozyczenia)
print(f'największa liczba wypożyczeń to {longest:0.0%} średniej wypożyczeń')
print(f'najmniejsza liczba wypożyczeń to {shortest:0.0%} średniej wypożyczeń')
