def get_sredniaodchyl(n):
    average = sum(n)/len(n)
    skalowanie = [x/average for x in n]
    skalowanie.sort(reverse=True)
    return skalowanie