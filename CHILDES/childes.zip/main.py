class Base(object):

    def __init__(self,name):
        self.name = name

    def get_name(self):
        return self.name


class Child(Base):

    def __init__(self,name,age):
        super().__init__(name)
        self.age = age

    def get_age(self):
        return self.age

class Uczelnia:

    def __init__(self,sname,scity):
        self.name = sname
        self.city = scity

    def get_school_name(self):
        return self.name

    def get_school_city(self):
        return self.city


class GrandChild(Child,Uczelnia):

    def __init__(self,name,age,city,sname, scity):
        Child.__init__(self,name,age)
        Uczelnia.__init__(self,sname,scity)
        self.city = city

    def get_city(self):
        return self.city

wnuk = GrandChild("Bonifacy",19,"Kraków","Uniwersytet Jagielloński","Kraków")
print(f"student -> imię: {wnuk.get_name()}, wiek: {wnuk.get_age()},"
      f" miasto: {wnuk.get_city()},\nuczelnia: {wnuk.get_school_name()}, miasto uczelni: {wnuk.get_school_city()}")

#sprawdzenie dziedziczenia

print(issubclass(Child,Base))
print(issubclass(Base,Child))
print(issubclass(GrandChild,Child))
print(issubclass(GrandChild,Uczelnia))

