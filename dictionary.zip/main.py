samochod = {
    "marka":"Ford",
    "model":"Mustang",
    "rocznik":1972,
    "poj":4.2
}
print(samochod)
print(samochod["model"])
print(samochod.get("model"))
samochod["rocznik"] = 2018
print(samochod)

samochod["przebieg"] = 67500
print(samochod)

print(len(samochod))

print(samochod.items())
print(samochod.keys())
print(samochod.values())

print("________________________________")

for s in samochod:
    print(s)

print("________________________________")

for s in samochod:
    print(samochod[s])

print("________________________________")

for s in samochod.values():
    print(s)

print("________________________________")


for x,y in samochod.items():
    print(x,":",y)

autokomis = {
    "auto1":{
        "marka":"Ford",
        "model":"Mustang",
        "rocznik":1972,
        "poj":4.2
    },
    "auto2": {
        "marka": "Opel",
        "model": "Vectra",
        "rocznik": 2008,
        "poj": 41.9
    },
    "auto3": {
        "marka": "Jeep",
        "model": "Cherokee",
        "rocznik": 2019,
        "poj": 4.8
    }
}

print(autokomis["auto1"])
print(autokomis["auto1"]["marka"])

for a in autokomis.values():
    print(a)

for x in autokomis:
    print("___________",x,"_____________")
    for a,b in autokomis[x].items():
        print(a,":",b)
