miasto = "Lublin"
imie = "Tomasz"
wiek = 29

osoba = "dane osoby: miasto -> {}, imię -> {}, wiek -> {}."
print(osoba.format(miasto,imie,wiek))

osoba = "dane osoby: imię -> {1}, wiek -> {2}, miasto -> {0}."
print(osoba.format(miasto,imie,wiek))

#f-string

kierunek = "informatyka"
uczelnia = "Politechnika Śląska"

student = f"student ({uczelnia}, {kierunek}) -> imię -> {imie}, wiek -> {wiek}, miasto -> {miasto}"
print(student)

id = "wart_abc"
value = 674.2546

formatowanie = "%-30s = %.2f" %(id,value)
print(formatowanie)

owoce = [
    ('awokado',7.88),
    ('banan',4.99),
    ('mandarynka',8.05),
    ('jabłko',3.55),
    ('maliny',23)
]

#zbuduj cennik -> #nr: wartosc (wyrównanie do 10 znaków) = 0.00 zł

print("__________________________________________")
for i,(nazwa,cena) in enumerate(owoce):
    print('#%d: %-10s = %.2f zł' %(i,nazwa,cena))

print("__________________________________________")
for i,(nazwa,cena) in enumerate(owoce):
    print('#%d: %-10s = %.2f zł' %(
        i+1,
        nazwa.title(),
        round(cena,1)
    ))

def to_lowercase(dane):
    return dane.lower()

tekst = "Bardzo Ważny Temat"
print(f"Rozdzial o tytule: {to_lowercase(tekst)}")