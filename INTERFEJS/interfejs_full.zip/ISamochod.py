from abc import ABCMeta, abstractmethod

class ISamochod:

    __metaclass__ = ABCMeta
    @abstractmethod
    def samochod_info(self):raise NotImplementedError

    @abstractmethod
    def licznik_km(self,zliczenie_start, zliczenie_koniec):raise NotImplementedError