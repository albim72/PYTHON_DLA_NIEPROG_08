from pojazd import Pojazd


stan_pocz = float(input("Podaj początkowy stan licznika: "))
stan_kn= float(input("Podaj końcowy stan licznika: "))
marka= input("Podaj nazwę marki: ")
model= input("Podaj model: ")
poj= float(input("Podaj pojemność: "))
rocznik= int(input("Podaj rocznik: "))
przebieg= stan_kn

poj1 = Pojazd(marka,model,poj,rocznik,przebieg)


ltr = float(input("Podaj liczbę spalonych litrów paliwa: "))
odl = poj1.licznik_km(stan_pocz,stan_kn)
cn = float(input("Podaj cenę za litr paliwa: "))

poj1.samochod_info()

print(f"trasa {poj1.licznik_km(stan_pocz,stan_kn)} km")

print(f"spalanie na 100 km: {poj1.spalanie(ltr,odl):.2f} litrów")

print(f"koszt przejazdu na trasie {odl} km wynosi: {poj1.kosztyprzejazdu(ltr,odl,cn):.2f} zł")


#zbuduj interfejs ISamochod (klasa anstrakcyjna) z metodami (pustymi, abstrakcyjnymi)
# samochod_info(marka,model,poj, rocznik,przebieg -> elementy konstruktora), licznik_km(zliczenie_start, zliczenie_koniec)
#w klasie Pojazd zaimplementuj interfejs ISamochod i zdefiniuj metody..... ?? czy konstruktor w klasie Pojazd
# czy lokalne atrybuty właściwych funkcji --> jeśli w interfejsie definiujesz parametry to konsekwentnie wstawiasz je lokalnie
#jeśli nie deklarujesz to przekazujesz przez konstruktor



