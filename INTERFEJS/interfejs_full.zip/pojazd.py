from ipojazd import IPojazd
from ISamochod import ISamochod

class Pojazd(IPojazd,ISamochod):

    def __init__(self,marka,model,poj, rocznik,przebieg):
        self.marka = marka
        self.model = model
        self.poj = poj
        self.rocznik = rocznik
        self.przebieg = przebieg

    def spalanie(self, litry, odl):
        return litry*100/odl

    def kosztyprzejazdu(self, litry, odl, cena_l):
        return self.spalanie(litry,odl)*odl/100*cena_l

    def samochod_info(self):
        print(f"dane samochodu -> marka: {self.marka}, model: {self.model}, pojemność silnika: {self.poj}"
              f" rocznik: {self.rocznik}, przebieg: {self.przebieg} km")

    def licznik_km(self, zliczenie_start, zliczenie_koniec):
        return (zliczenie_koniec - zliczenie_start)

