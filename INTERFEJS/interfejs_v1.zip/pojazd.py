from ipojazd import IPojazd

class Pojazd(IPojazd):

    def spalanie(self, litry, odl):
        return litry*100/odl

    def kosztyprzejazdu(self, litry, odl, cena_l):
        return self.spalanie(litry,odl)*odl/100*cena_l