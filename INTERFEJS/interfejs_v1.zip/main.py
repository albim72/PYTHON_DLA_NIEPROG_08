from pojazd import Pojazd

poj1 = Pojazd()
ltr = float(input("Podaj liczbę spalonych litrów paliwa: "))
odl = float(input("Podaj przejechaną odległość w km: "))
cn = float(input("Podaj cenę za litr paliwa: "))
print(f"spalanie na 100 km: {poj1.spalanie(ltr,odl):.2f} litrów")

print(f"koszt przejazdu na trasie {odl} km wynosi: {poj1.kosztyprzejazdu(ltr,odl,cn):.2f} zł")
