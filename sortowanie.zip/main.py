wyrazy_classic = ['samolot','marchewka','mecz','miecz','mieczyk','Mieczysław','atak','zenit',
                  'piorun','macierz','Toruń']

for i,wyraz in enumerate(wyrazy_classic):
    wyrazy_classic[i] = wyraz.lower()

def bubblesort_classic(a):
    for _ in range(len(a)):
        for i in range(1,len(a)):
            if a[i] < a[i-1]:
                temp = a[i]
                a[i] = a[i-1]
                a[i-1] = temp

bubblesort_classic(wyrazy_classic)
print(wyrazy_classic)
wyrazy_modern = ['samolot','marchewka','mecz','miecz','mieczyk','Mieczysław','atak','zenit',
                  'piorun','macierz','Toruń']

for i,wyraz in enumerate(wyrazy_modern):
    wyrazy_modern[i] = wyraz.lower()

def bubblesort_modern(a):
    for _ in range(len(a)):
        for i in range(1,len(a)):
            if a[i] < a[i-1]:
              a[i-1],a[i] = a[i],a[i-1]

bubblesort_modern(wyrazy_modern)
print(wyrazy_modern)